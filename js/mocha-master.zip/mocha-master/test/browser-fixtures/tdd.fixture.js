'use strict';

/* eslint-env browser */

window.mocha.timeout(200)
  .ui('tdd');
