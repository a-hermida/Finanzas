'use strict';

// Root-only test cases
it.only('#Root-Suite, should run this bdd test-case #1', function () {
  (true).should.equal(true);
});

it('#Root-Suite, should not run this bdd test-case #2', function () {
  (false).should.equal(true);
});

it('#Root-Suite, should not run this bdd test-case #3', function () {
  (false).should.equal(true);
});
