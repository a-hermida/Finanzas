'use strict';

global.expect = require('expect.js');
global.assert = require('assert');
