'use strict';

xdescribe('a pending suite without a callback');
