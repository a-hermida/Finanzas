'use strict';

describe('a suite without a callback');
