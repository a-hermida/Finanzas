'use strict';

describe('grep', function () {
  describe('Match', function () {
    it('should run', function () {});
    it('should also run', function () {});
  });

  describe('match', function () {
    it('should run', function () {});
    it('should also run', function () {});
  });

  describe('fail', function () {
    it('should not be ran', function () {
      throw new Error('Spec should not run');
    });
  });
});
