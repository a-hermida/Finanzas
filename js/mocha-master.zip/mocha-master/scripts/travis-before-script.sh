#!/usr/bin/env bash

mkdir -p .karma
